#include "funciones_grupo.h"

/////////////////////////////////////////NEGATIVO//////////////////////////////////////////////////////////////////////
void Negativo(IMAGEN bit_map,char *nom_imagen)
{
    size_t i, j, k;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    char nombre[TAM] = "ADOBE_negativo_";
    strcat(nombre,nom_imagen);
    for(i = 0 ; i < filas ; i++)
    {
        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {
            for(k = 0 ; k < 3 ; k++)
            {

                bit_map.pixeles[i][j].bgr[k]=255-bit_map.pixeles[i][j].bgr[k];

            }
        }

    }

    CrearImagen(bit_map,nombre);

}

//////////////////////////////////////////ESCALA DE GRISES///////////////////////////////////////////////
void EscaladeGrises(IMAGEN bit_map,char *nom_imagen)
{
    size_t i, j, k,aux=0;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    char nombre[TAM] = "ADOBE_escala-de-grises_";
    strcat(nombre,nom_imagen);


    for(i = 0 ; i < filas ; i++)
    {

        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {


            for(k = 0 ; k < 3 ; k++)
            {
                aux = aux+bit_map.pixeles[i][j].bgr[k];
            }
            aux=aux/3;

            for(k = 0 ; k < 3 ; k++)
            {
                bit_map.pixeles[i][j].bgr[k]=aux;
            }
            aux=0;
        }

    }
    CrearImagen(bit_map,nombre);

}

///////////////////////////////////////ESPEJAR HORIZONTAL////////////////////////////////////////////////
void EspejarHorizontal(IMAGEN bit_map,char *nom_imagen)
{
    size_t i, j, k, fin_col;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    char nombre[TAM] = "ADOBE_espejar-horizontal_";
    strcat(nombre,nom_imagen);
    PIXEL aux;

    for(i = 0 ; i <filas ; i++)
    {
        fin_col=bit_map.cab_info.ancho-1;
        for(j = 0 ; j < fin_col ; j++)
        {
            for(k = 0 ; k < 3 ; k++)
            {
                aux.bgr[k]=bit_map.pixeles[i][j].bgr[k];

                bit_map.pixeles[i][j].bgr[k]=bit_map.pixeles[i][fin_col].bgr[k];

                bit_map.pixeles[i][fin_col].bgr[k]=aux.bgr[k];
            }
            fin_col--;

        }

    }
    CrearImagen(bit_map,nombre);

}


/////////////////////////////REDUCIR CONTRASTE////////////////////////////////////////
void ReducirContraste(IMAGEN bit_map,char *nom_imagen,float porcentaje)
{

    size_t i, j, k;
    float nuevo_valor=0;
    float factor = (porcentaje < 0) ? 0 : (porcentaje>100)? 100:porcentaje;
    factor =factor/100.0;
    char nombre[TAM] = "ADOBE_reducir-contraste_";
    strcat(nombre,nom_imagen);


    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    for(i = 0 ; i < filas ; i++)
    {
        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {

            for(k = 0 ; k < 3 ; k++)
            {
                nuevo_valor =128.0+(1.0-factor)*((float)bit_map.pixeles[i][j].bgr[k]-128.0);
                if (nuevo_valor <= 0)
                {
                    nuevo_valor = 0;
                }
                if (nuevo_valor > 255)
                {
                    nuevo_valor = 255;
                }
                bit_map.pixeles[i][j].bgr[k] = nuevo_valor;
            }

        }

    }
    CrearImagen(bit_map,nombre);

}
/////////////////////////////////////////////////////TONALIDAD AZUL//////////////////////////////////
void TonalidadAzul(IMAGEN bit_map,char *nom_imagen,float porcentaje)
{
    float factor = (porcentaje < -100) ? -100 : (porcentaje>100)? 100:porcentaje;
    factor = 1.0 + (porcentaje / 100.0);
    char nombre[TAM] = "ADOBE_tonalidad-azul_";
    strcat(nombre,nom_imagen);

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;

    for (size_t i = 0; i < filas; i++)
    {
        for (size_t j = 0; j < columnas; j++)
        {
            float azul_modificado = (float)bit_map.pixeles[i][j].bgr[0] * factor;

            if (azul_modificado > 255.0)
                bit_map.pixeles[i][j].bgr[0] = 255;
            else if (azul_modificado < 0.0)
                bit_map.pixeles[i][j].bgr[0] = 0;
            else
                bit_map.pixeles[i][j].bgr[0] = (uint8_t)azul_modificado;
        }
    }
    CrearImagen(bit_map,nombre);

}
////////////////////////////////////////ACHICAR////////////////////////////////////////////////
void AchicarImagen(IMAGEN bit_map,char *nom_imagen, float factor)
{
    PIXEL **matriz_reducida;
    int ancho_redu, alto_redu, x, y, x1, y1,i,j,k,columnas;
    size_t padding;
    float escala_x, escala_y;

    if (factor <= 0.0 || factor > 100.0)
        exit(1);
    factor=factor/100.0;
    char nombre[TAM] = "ADOBE_achicar_";
    strcat(nombre,nom_imagen);


    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    columnas=bit_map.cab_info.ancho;

    alto_redu=filas*factor;

    ancho_redu=bit_map.cab_info.ancho*factor;

    escala_x=bit_map.cab_info.ancho/ancho_redu;
    escala_y=filas/alto_redu;


    padding=(4-(ancho_redu*3)%4)%4;
    bit_map.cab_info.tamImagen=(ancho_redu*3+padding)*alto_redu;
    bit_map.cab_file.tamArchivo=bit_map.cab_info.tamImagen+bit_map.cab_info.tamCabecera+sizeof(uint8_t)*14;
    bit_map.cab_info.ancho=ancho_redu;
    bit_map.cab_info.alto=bit_map.cab_info.alto*factor;

    matriz_reducida=crearMatriz(alto_redu,ancho_redu);

    if (!matriz_reducida)
    {
        printf("error al crear nueva matriz reducida\n");
        exit(1);
    }



    for(i = 0 ; i < alto_redu ; i++)
    {
        y = (int)escala_y * i;
        y1 = (y+1<filas-1)?y+1:filas-1;

        for(j = 0 ; j < ancho_redu ; j++)
        {
            x = (int)escala_x * j;
            x1 = (x+1<columnas-1)?x+1:columnas-1;

            for(k = 0 ; k < 3 ; k++)
            {

                matriz_reducida[i][j].bgr[k]=(bit_map.pixeles[y][x].bgr[k] + bit_map.pixeles[y][x1].bgr[k] + bit_map.pixeles[y1][x].bgr[k] + bit_map.pixeles[y1][x1].bgr[k]) / 4;

            }

        }

    }

    bit_map.pixeles=matriz_reducida;

    CrearImagen(bit_map,nombre);
    liberarMatriz(matriz_reducida,alto_redu);

}

////////////////////////////////ROTAR DERECHA////////////////////////////////
void RotarDerecha(IMAGEN bit_map,char *nom_imagen)
{

    int i, j;

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;
    int aux;
    char nombre[TAM] = "ADOBE_rotar-derecha_";
    strcat(nombre,nom_imagen);


    PIXEL** nueva_matriz = crearMatriz(columnas, filas);
    if (!nueva_matriz)
    {
        printf("error al crear nueva matriz de rotacion\n");
        exit(1);
    }


    for (i = 0; i < filas; i++)
    {
        for (j = 0; j < columnas; j++)
        {
            nueva_matriz[j][i] = bit_map.pixeles[i][j];
        }
    }
    bit_map.pixeles=nueva_matriz;
    aux=bit_map.cab_info.alto;
    bit_map.cab_info.alto=bit_map.cab_info.ancho;
    bit_map.cab_info.ancho=aux;

    CrearImagen(bit_map,nombre);
    liberarMatriz(nueva_matriz,columnas);

}
//////////////////////////////////////CONCATENAR VERTICAL///////////////////////////////////////
void ConcatenarVertical(IMAGEN bit_map,char *nom_imagen, char *nom_imagen1)
{

    IMAGEN bit_map_2;
    bit_map_2=CrearArchivo(nom_imagen);
    size_t filas1 = (bit_map.cab_info.alto < 0) ? -bit_map.cab_info.alto : bit_map.cab_info.alto;
    size_t filas2 = (bit_map_2.cab_info.alto < 0) ? -bit_map_2.cab_info.alto : bit_map_2.cab_info.alto;
    size_t columnas1 = bit_map.cab_info.ancho;
    size_t columnas2 = bit_map_2.cab_info.ancho;
    char nombre[TAM] = "ADOBE_concatenar-vertical_";
    strcat(nombre,nom_imagen1);
    strcat(nombre,"_");
    strcat(nombre,nom_imagen);


    int nuevasFilas = filas1 + filas2;
    int maxColumnas = (columnas1 > columnas2) ? columnas1 : columnas2;

    bool img1_arriba = (bit_map.cab_info.alto < 0)?true:false;
    bool img2_arriba = (bit_map_2.cab_info.alto < 0)?true:false;


    if (!img1_arriba)
        invertirVertical(bit_map.pixeles, filas1);
    if (!img2_arriba)
        invertirVertical(bit_map_2.pixeles, filas2);




    PIXEL** nuevaMatriz = crearMatriz(nuevasFilas, maxColumnas);
    if (!nuevaMatriz)
    {
        printf("error al crear nueva matriz extendida\n");
        exit(1);
    }


    PIXEL relleno;
    relleno.bgr[0] = 180;
    relleno.bgr[1] = 105;
    relleno.bgr[2] = 255;



    for (size_t i = 0; i < filas1; i++)
    {
        for (size_t j = 0; j < maxColumnas; j++)
        {
            if (j < columnas1)
                nuevaMatriz[i][j] = bit_map.pixeles[i][j];
            else
                nuevaMatriz[i][j] = relleno;
        }
    }


    for (size_t i = 0; i < filas2; i++)
    {
        for (size_t j = 0; j < maxColumnas; j++)
        {
            if (j < columnas2)
                nuevaMatriz[i + filas1][j] = bit_map_2.pixeles[i][j];
            else
                nuevaMatriz[i + filas1][j] = relleno;
        }
    }


    bit_map.pixeles=nuevaMatriz;

    bit_map.cab_info.ancho = maxColumnas;
    bit_map.cab_info.alto = -nuevasFilas;

    size_t fila_bytes = maxColumnas * 3;
    size_t padding = (4 - (fila_bytes % 4)) % 4;
    bit_map.cab_info.tamImagen = (fila_bytes + padding) * nuevasFilas;

    bit_map.cab_file.tamArchivo = bit_map.cab_info.tamImagen + bit_map.cab_info.tamCabecera + sizeof(uint8_t)*14;


    CrearImagen(bit_map,nombre);


    liberarMatriz(nuevaMatriz, nuevasFilas);

    liberarMatriz(bit_map_2.pixeles,filas2);

}

