#include "funciones_grupo.h"


int main(int argc, char *argv[])
{
    IMAGEN foto;
    int factor=0;
    int i = 0,band=0;
    int hizo_negativo = 0, hizo_grises = 0, hizo_espejoH = 0, hizo_espejoV = 0;
    int hizo_aumentar = 0, hizo_reducir = 0, hizo_tonoA = 0, hizo_tonoV = 0, hizo_tonoR = 0;
    int hizo_recortar = 0, hizo_achicar = 0, hizo_rotD = 0, hizo_rotI = 0;
    int hizo_concatH = 0, hizo_concatV = 0, hizo_comodin = 0;
    if (argc < 3) {
        printf("Error: Se deben pasar al menos dos argumentos.\n");
        return 1;
    }
    if(strncmp(argv[2], "--", 2)==0)
        {
            printf("el segundo argumento debe ser una imagen\n");
            getchar();
            exit(1);
        }
    foto=CrearArchivo(argv[2]);

    for (i = 1; i < argc; i++)
    {

        if (strcmp(argv[i], "--negativo") == 0 && !hizo_negativo)
        {
            Negativo(foto,argv[2]);
            hizo_negativo = 1;
        }
        else if (strcmp(argv[i], "--escala-de-grises") == 0 && !hizo_grises)
        {
            EscaladeGrises(foto, argv[2]);
            hizo_grises = 1;
        }
        else if (strcmp(argv[i], "--espejar-horizontal") == 0 && !hizo_espejoH)
        {
            EspejarHorizontal(foto, argv[2]);
            hizo_espejoH = 1;
        }
        else if (strcmp(argv[i], "--espejar-vertical") == 0 && !hizo_espejoV)
        {
            EspejarVertical(foto, argv[2]);
            hizo_espejoV = 1;
        }
        else if (strncmp(argv[i], "--aumentar-contraste=", 21) == 0 && !hizo_aumentar)
        {
            band=extraerNumeroDesdeIgual(argv[i],&factor);
            if(band)
            {
                AumentarContraste(foto,argv[2],(float)factor);
                hizo_aumentar = 1;
            }
        }
        else if (strncmp(argv[i], "--reducir-contraste=", 20) == 0 && !hizo_reducir)
        {
            band=extraerNumeroDesdeIgual(argv[i],&factor);
            if(band)
            {
                ReducirContraste(foto,argv[2],(float)factor);
                hizo_aumentar = 1;
            }
        }
        else if (strncmp(argv[i], "--tonalidad-azul=", 16) == 0 && !hizo_tonoA)
        {
            band = extraerNumeroDesdeIgual(argv[i], &factor);
            if (band)
            {
                TonalidadAzul(foto, argv[2], (float)factor);
                hizo_tonoA = 1;
            }
        }
        else if (strncmp(argv[i], "--tonalidad-verde=", 17) == 0 && !hizo_tonoV)
        {
            band = extraerNumeroDesdeIgual(argv[i], &factor);
            if (band)
            {
                TonalidadVerde(foto, argv[2], (float)factor);
                hizo_tonoV = 1;
            }
        }
        else if (strncmp(argv[i], "--tonalidad-roja=", 16) == 0 && !hizo_tonoR)
        {
            band = extraerNumeroDesdeIgual(argv[i], &factor);
            if (band)
            {
                TonalidadRoja(foto, argv[2], (float)factor);
                hizo_tonoR = 1;
            }
        }
        else if (strncmp(argv[i], "--recortar=", 11) == 0 && !hizo_recortar)
        {
            band = extraerNumeroDesdeIgual(argv[i], &factor);
            if (band)
            {
                recortarImagen(foto, argv[2], (float)factor);
                hizo_recortar = 1;
            }
        }
        else if (strncmp(argv[i], "--achicar=", 10) == 0 && !hizo_achicar)
        {
            band = extraerNumeroDesdeIgual(argv[i], &factor);
            if (band)
            {
                AchicarImagen(foto, argv[2], (float)factor);
                hizo_achicar = 1;
            }
        }
        else if (strcmp(argv[i], "--rotar-derecha") == 0 && !hizo_rotD)
        {
            RotarDerecha(foto, argv[2]);
            hizo_rotD = 1;
        }
        else if (strcmp(argv[i], "--rotar-izquierda") == 0 && !hizo_rotI)
        {
            RotarIzquierda(foto, argv[2]);
            hizo_rotI = 1;
        }
        else if (strcmp(argv[i], "--concatenar-horizontal") == 0 && !hizo_concatH)
        {
            if(i + 1 < argc)
            {
                if(strncmp(argv[i+1], "--", 2)!=0)
                {
                    if (i + 2 < argc)
                    {
                        if (strcmp(argv[i + 1], argv[2]) == 0)
                        {
                            ConcatenarHorizontal(foto, argv[i + 2], argv[2]);
                        }
                        else
                        {
                            IMAGEN foto2 = CrearArchivo(argv[i + 1]);
                            ConcatenarHorizontal(foto2, argv[i + 2], argv[i + 1]);
                        }
                        hizo_concatH = 1;
                    }
                    else
                    {
                        printf("no hay suficientes imagenes para concatenar\n");
                    }
                }
                else
                {
                    printf("no hay suficientes imagenes para concatenar\n");
                }
            }
            else
            {
                printf("no hay imagenes para concatenar\n");
            }
        }
        else if (strcmp(argv[i], "--concatenar-vertical") == 0 && !hizo_concatV)
        {
            if(i + 1 < argc)
            {
                if(strncmp(argv[i+1], "--", 2)!=0)
                {
                    if (i + 2 < argc)
                    {
                        if(strcmp(argv[i+1],argv[2])==0)
                        {
                            ConcatenarVertical(foto,argv[i+2],argv[2]);
                        }
                        else
                        {
                            IMAGEN foto2;
                            foto2=CrearArchivo(argv[i+1]);
                            ConcatenarVertical(foto2,argv[i+2],argv[i+1]);
                            liberarMatriz(foto2.pixeles,foto2.cab_info.alto);
                        }
                        hizo_concatV = 1;
                    }
                    else
                    {
                        printf("no hay suficientes imagenes para concatenar\n");
                    }
                }
                else
                {
                    printf("no hay suficientes imagenes para concatenar\n");
                }
            }
            else
            {
                printf("no hay imagenes para concatenar\n");
            }
        }
        else if (strcmp(argv[i], "--comodin") == 0 && !hizo_comodin)
        {
            Comodin(foto, argv[2]);
            hizo_comodin = 1;
        }
        if(i + 1 < argc)
        {
            if(strncmp(argv[i+1], "--", 2)==0)
            {
                if(foto.cab_info.tamCabecera>40)
                    liberarvector(foto.vect);
                liberarMatriz(foto.pixeles,foto.cab_info.alto);
                foto=CrearArchivo(argv[2]);
            }
        }

    }
    if(foto.cab_info.tamCabecera>40)
        liberarvector(foto.vect);

    liberarMatriz(foto.pixeles,foto.cab_info.alto);


    return EXIT_SUCCESS;
}
