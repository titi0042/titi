#include "funciones_grupo.h"


//////////////////////////////////ESPEJADO VERTICAL//////////////////////////////////////////////////
void EspejarVertical(IMAGEN bit_map,char *nom_imagen)
{
    size_t i, j, k, fin_fi;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    char nombre[TAM] = "ADOBE_espejar-vertical_";
    strcat(nombre,nom_imagen);
    PIXEL aux;


    for(i = 0 ; i <bit_map.cab_info.ancho ; i++)
    {
        fin_fi=filas-1;
        for(j = 0 ; j < fin_fi ; j++)
        {
            for(k = 0 ; k < 3 ; k++)
            {
                aux.bgr[k]=bit_map.pixeles[j][i].bgr[k];

                bit_map.pixeles[j][i].bgr[k]=bit_map.pixeles[fin_fi][i].bgr[k];

                bit_map.pixeles[fin_fi][i].bgr[k]=aux.bgr[k];
            }
            fin_fi--;

        }
    }
    CrearImagen(bit_map,nombre);

}

/////////////////////////////////AUMENTAR CONTRASTE/////////////////////////////////
void AumentarContraste(IMAGEN bit_map,char *nom_imagen,float porcentaje)
{

    size_t i, j, k;
    float nuevo_valor=0;
    float factor = (porcentaje < 0) ? 0 : (porcentaje>100)? 100:porcentaje;
    factor=factor/100.0+1.0;
    char nombre[TAM] = "ADOBE_aumentar-contraste_";
    strcat(nombre,nom_imagen);


    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;

    for(i = 0 ; i < filas ; i++)
    {
        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {

            for(k = 0 ; k < 3 ; k++)
            {
                nuevo_valor =128.0+(factor*((float)bit_map.pixeles[i][j].bgr[k]-128.0));
                if (nuevo_valor <= 0)
                {
                    nuevo_valor = 0;
                }
                if (nuevo_valor > 255)
                {
                    nuevo_valor = 255;
                }
                bit_map.pixeles[i][j].bgr[k] = nuevo_valor;
            }

        }
    }
    CrearImagen(bit_map,nombre);

}
///////////////////////////////TONALIDAD VERDE////////////////////////////
void TonalidadVerde(IMAGEN bit_map,char *nom_imagen,float porcentaje)
{
    float factor = (porcentaje < -100) ? -100 : (porcentaje>100)? 100:porcentaje;
    factor = 1.0 + (porcentaje / 100.0);
    char nombre[TAM] = "ADOBE_tonalidad-verde_";
    strcat(nombre,nom_imagen);

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;

    for (size_t i = 0; i < filas; i++)
    {
        for (size_t j = 0; j < columnas; j++)
        {
            float verde_modificado = (float)bit_map.pixeles[i][j].bgr[1] * factor;

            if (verde_modificado > 255.0)
                bit_map.pixeles[i][j].bgr[1] = 255;
            else if (verde_modificado < 0.0)
                bit_map.pixeles[i][j].bgr[1] = 0;
            else
                bit_map.pixeles[i][j].bgr[1] = (uint8_t)verde_modificado;
        }
    }
    CrearImagen(bit_map,nombre);

}

/////////////////////////////////////TONALIDAD ROJO////////////////////////////
void TonalidadRoja(IMAGEN bit_map,char *nom_imagen,float porcentaje)
{
    float factor = (porcentaje < -100) ? -100 : (porcentaje>100)? 100:porcentaje;
    factor = 1.0 + (porcentaje / 100.0);
    char nombre[TAM] = "ADOBE_tonalidad-roja_";
    strcat(nombre,nom_imagen);

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;

    for (size_t i = 0; i < filas; i++)
    {
        for (size_t j = 0; j < columnas; j++)
        {
            float rojo_modificado = (float)bit_map.pixeles[i][j].bgr[2] * factor;

            if (rojo_modificado > 255.0)
                bit_map.pixeles[i][j].bgr[2] = 255;
            else if (rojo_modificado < 0.0)
                bit_map.pixeles[i][j].bgr[2] = 0;
            else
                bit_map.pixeles[i][j].bgr[2] = (uint8_t)rojo_modificado;
        }
    }
    CrearImagen(bit_map,nombre);

}
////////////////////////////////////////RECORTAR//////////////////////////////////////////
void recortarImagen(IMAGEN bit_map,char *nom_imagen, float porcentaje)
{
    float factor = (porcentaje < 0) ? 0 : (porcentaje>100)? 100:porcentaje;
    factor = 1.0 - (porcentaje / 100.0);
    char nombre[TAM] = "ADOBE_recortar_";
    strcat(nombre,nom_imagen);
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;
    int fila_redu = (filas * factor);
    int columna_redu = (columnas * factor);
    int padding;


    PIXEL **recorte = crearMatriz(fila_redu,columna_redu);
    if (!recorte)
    {
        printf("error al crear nueva matriz recortada");
        exit(1);
    }

    for (size_t i = 0; i < fila_redu; i++)
    {
        for (size_t j = 0; j < columna_redu; j++)
        {
            recorte[i][j] = bit_map.pixeles[i][j];
        }
    }
    padding=(4-(columna_redu*3)%4)%4;
    bit_map.cab_info.tamImagen=(columna_redu*3+padding)*fila_redu;
    bit_map.cab_file.tamArchivo=bit_map.cab_info.tamImagen+bit_map.cab_info.tamCabecera+sizeof(uint8_t)*14;
    bit_map.cab_info.ancho=columna_redu;
    bit_map.cab_info.alto=bit_map.cab_info.alto*(factor);
    bit_map.pixeles=recorte;
    CrearImagen(bit_map,nombre);
    liberarMatriz(recorte,fila_redu);

}
////////////////////////////////ROTAR IZQUIERDA////////////////////////////////
void RotarIzquierda(IMAGEN bit_map, char *nom_imagen)
{

    int i, j;

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;
    int aux;
    char nombre[TAM] = "ADOBE_rotar-izquierda_";
    strcat(nombre,nom_imagen);


    PIXEL** nueva_matriz = crearMatriz(columnas, filas);
    if (!nueva_matriz)
    {
        printf("error al crear nueva matriz de rotacion\n");
        exit(1);
    }

    for (i = 0; i < filas; i++)
    {
        for (j = 0; j < columnas; j++)
        {
            nueva_matriz[j][filas - i - 1] = bit_map.pixeles[i][j];
        }
    }
    bit_map.pixeles=nueva_matriz;
    aux=bit_map.cab_info.alto;
    bit_map.cab_info.alto=bit_map.cab_info.ancho;
    bit_map.cab_info.ancho=aux;

    CrearImagen(bit_map,nombre);
    liberarMatriz(nueva_matriz,columnas);

}
/////////////////////////////CONCATENAR HORIZONTAL///////////////////////////
void ConcatenarHorizontal(IMAGEN bit_map,char *nom_imagen, char *nom_imagen1)
{
    IMAGEN bit_map_2;
    bit_map_2 = CrearArchivo(nom_imagen);
    size_t filas1 = (bit_map.cab_info.alto < 0) ? -bit_map.cab_info.alto : bit_map.cab_info.alto;
    size_t filas2 = (bit_map_2.cab_info.alto < 0) ? -bit_map_2.cab_info.alto : bit_map_2.cab_info.alto;
    size_t columnas1 = bit_map.cab_info.ancho;
    size_t columnas2 = bit_map_2.cab_info.ancho;
    char nombre[TAM] = "ADOBE_concatenar-horizontal_";
    strcat(nombre,nom_imagen1);
    strcat(nombre,"_");
    strcat(nombre,nom_imagen);


    bool img1_arriba = bit_map.cab_info.alto < 0;
    bool img2_arriba = bit_map_2.cab_info.alto < 0;

    if (!img1_arriba)
        invertirVertical(bit_map.pixeles, filas1);
    if (!img2_arriba)
        invertirVertical(bit_map_2.pixeles, filas2);

    size_t maxFilas = (filas1 > filas2)?filas1:filas2;

    size_t nuevasColumnas = columnas1 + columnas2;


    PIXEL **nuevaMatriz = crearMatriz(maxFilas, nuevasColumnas);
    if (!nuevaMatriz)
    {
        printf("error al crear nueva matriz extendida\n");
        exit(1);
    }

    PIXEL relleno;
    relleno.bgr[0] = 180;
    relleno.bgr[1] = 105;
    relleno.bgr[2] = 255;

    for (size_t i = 0; i < maxFilas; i++)
    {
        for (size_t j = 0; j < columnas1; j++)
        {
            if (i < filas1)
                nuevaMatriz[i][j] = bit_map.pixeles[i][j];
            else
                nuevaMatriz[i][j] = relleno;
        }
    }

    for (size_t i = 0; i < maxFilas; i++)
    {
        for (size_t j = 0; j < columnas2; j++)
        {
            if (i < filas2)
                nuevaMatriz[i][j + columnas1] = bit_map_2.pixeles[i][j];
            else
                nuevaMatriz[i][j + columnas1] = relleno;
        }
    }


    bit_map.pixeles=nuevaMatriz;
    bit_map.cab_info.ancho = nuevasColumnas;
    bit_map.cab_info.alto = -maxFilas;

    size_t fila_bytes = nuevasColumnas * 3;
    size_t padding = (4 - (fila_bytes % 4)) % 4;
    bit_map.cab_info.tamImagen = (fila_bytes + padding) * maxFilas;

    bit_map.cab_file.tamArchivo = bit_map.cab_info.tamImagen + bit_map.cab_info.tamCabecera + sizeof(uint8_t)*14;

    CrearImagen(bit_map,nombre);
    liberarMatriz(nuevaMatriz, maxFilas);
    liberarMatriz(bit_map_2.pixeles,filas2);

}
////////////////////////////////////////COMODIN///////////////////////////////////////
void Comodin(IMAGEN bit_map, char *nom_imagen)
{
    size_t i, j;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    int columnas = bit_map.cab_info.ancho;
    char nombre[TAM] = "ADOBE_comodin_";
    strcat(nombre,nom_imagen);

    for (i = 0; i < filas; i++) {
        for (j = 0; j < columnas; j++) {
            uint8_t r = bit_map.pixeles[i][j].bgr[2];
            uint8_t g = bit_map.pixeles[i][j].bgr[1];
            uint8_t b = bit_map.pixeles[i][j].bgr[0];

            int intensidad = (int)(0.3 * r + 0.59 * g + 0.11 * b);

            if (intensidad < 50) {
                bit_map.pixeles[i][j].bgr[2] = 0;     // R
                bit_map.pixeles[i][j].bgr[1] = 0;     // G
                bit_map.pixeles[i][j].bgr[0] = 255;   // B
            } else if (intensidad < 100) {
                bit_map.pixeles[i][j].bgr[2] = 0;
                bit_map.pixeles[i][j].bgr[1] = 255;
                bit_map.pixeles[i][j].bgr[0] = 255;
            } else if (intensidad < 150) {
                bit_map.pixeles[i][j].bgr[2] = 0;
                bit_map.pixeles[i][j].bgr[1] = 255;
                bit_map.pixeles[i][j].bgr[0] = 0;
            } else if (intensidad < 200) {
                bit_map.pixeles[i][j].bgr[2] = 255;
                bit_map.pixeles[i][j].bgr[1] = 255;
                bit_map.pixeles[i][j].bgr[0] = 0;
            } else {
                bit_map.pixeles[i][j].bgr[2] = 255;
                bit_map.pixeles[i][j].bgr[1] = 0;
                bit_map.pixeles[i][j].bgr[0] = 0;
            }
        }
    }

    CrearImagen(bit_map, nombre);
}
