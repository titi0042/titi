#include "funciones_grupo.h"
/*

Apellido(s), nombre(s): Luna Gauna, Thiago Gonzalo
DNI: 45738676
Entrega: S�.

Apellido(s), nombre(s): Zacarias, Franco Hernan
DNI: 46422064
Entrega: S�.

Apellido(s), nombre(s): Jimenez, Rocio Ayelen
DNI: 46644388
Entrega: No.


Un llamado v�lido al programa podr�a ser:
bmpmanipuleitor.exe --negativo unlam.bmp --escala-de-grises
--argumento-incorrecto-que-debera-ser-ignorado
--aumentar-contraste=18 --negativo

-En base a este ejemplo extraido del enunciado y otros presentes en la consigna, la posicion de la imagen sobre la cual se efectuan
los cambios sera siempre la del tercer argumento (segundo argumento despues del .exe) en la terminal, siendo la unica excepcion la de las ordenes de concatenacion que tomaran
como imagenes a los dos argumentos siguientes a su llamado, en caso de que una de ellas no sea la primera operacion.

*/


//////////////////////////////////////////LIBERAR VECTOR//////////////////////////////////////////////////////
void liberarvector(uint8_t* vect)
{
    free(vect);
}
//////////////////////////////////////////CREAR VECTOR//////////////////////////////////////////////////////
uint8_t* crearvector( size_t ce)
{
    uint8_t *vector = (uint8_t*)malloc(ce * sizeof(uint8_t));

    if(vector == NULL)
    {
        return NULL;
    }
    return vector;
}
//////////////////////////////////////////LIBERAR MATRIZ//////////////////////////////////////////////////////
void liberarMatriz(PIXEL** matriz, size_t filas)
{
    size_t i;
    for(i = 0 ; i < filas ; i++)
        free(matriz[i]);
    free(matriz);
}
//////////////////////////////////////////CREAR MATRIZ//////////////////////////////////////////////////////
PIXEL** crearMatriz(size_t filas, size_t columnas)
{
    size_t i;
    PIXEL **matriz = (PIXEL**)malloc(filas* sizeof(PIXEL*));

    if(matriz == NULL)
    {
        return NULL;
    }
    for(i = 0 ; i < filas ; i++)
    {
        *(matriz+i) = (PIXEL*)malloc(columnas* sizeof(PIXEL));

        if(*(matriz+i) == NULL)
        {
            liberarMatriz(matriz,i);
            return NULL;
        }
    }

    return matriz;

}
//////////////////////////////////////////LLENAR ARCHIVO//////////////////////////////////////////////////////
void llenarMatriz(IMAGEN bit_map, FILE *foto)
{
    size_t i, j,k, padding, fila_bytes;
    uint8_t bytes;
    fila_bytes = 3 * bit_map.cab_info.ancho;
    padding = (4 - (fila_bytes % 4)) % 4;
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;
    fseek(foto,bit_map.cab_file.offsetDatos,SEEK_SET);

    for(i = 0 ; i < filas; i++)
    {

        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {

            for(k = 0 ; k < 3 ; k++)
            {

                fread(&bytes,1,1,foto);
                bit_map.pixeles[i][j].bgr[k] = bytes;

            }

        }
        fseek(foto, padding, SEEK_CUR);
    }




}
//////////////////////////////////////////CREAR ARCHIVO//////////////////////////////////////////////////////
IMAGEN CrearArchivo(char *nom_imagen)
{
    FILE *archivo = fopen(nom_imagen, "rb");
    IMAGEN bit_map;
    uint8_t *vector;
    int columnas;
    if (!archivo)
    {
        printf("No se encontro la imagen: %s\n",nom_imagen);
        exit(1);
    }

    fread(&bit_map.cab_file, sizeof(BMPFileHeader), 1, archivo);
    fread(&bit_map.cab_info, sizeof(BMPInfoHeader), 1, archivo);



    if (bit_map.cab_file.tipo != 0x4D42 || bit_map.cab_info.bpp != 24)
    {
        fprintf(stderr, "Archivo no es un BMP de 24 bits.\n");
        fclose(archivo);
        exit(1);
    }

    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;

    columnas=bit_map.cab_info.ancho;



    if(bit_map.cab_info.tamCabecera>40)
    {
        vector=crearvector(bit_map.cab_info.tamCabecera-40);
        fread(vector,1,bit_map.cab_info.tamCabecera-40,archivo);
        bit_map.vect=vector;
    }


    bit_map.pixeles=crearMatriz(filas,columnas);

    llenarMatriz(bit_map,archivo);

    fclose(archivo);

    return bit_map;
}
//////////////////////////////////////////CREAR IMAGEN//////////////////////////////////////////////////////
void CrearImagen(IMAGEN bit_map,char nombre[60])
{
    uint8_t byte,cero=0;
    size_t i,j,k,padding;
    FILE *nuevaimagen;
    padding = (4-(3*bit_map.cab_info.ancho)% 4)%4;


    nuevaimagen=fopen(nombre,"wb");
    if (!nuevaimagen)
    {
        perror("error al crear imagen\n");
        exit(1);
    }
    fwrite(&bit_map.cab_file,sizeof(BMPFileHeader),1,nuevaimagen);

    fwrite(&bit_map.cab_info,sizeof(BMPInfoHeader),1,nuevaimagen);

    if(bit_map.cab_info.tamCabecera>40)
    {
        fwrite(&bit_map.vect,sizeof(uint8_t),bit_map.cab_info.tamCabecera-40,nuevaimagen);
    }
    int filas = (bit_map.cab_info.alto > 0) ? bit_map.cab_info.alto : -bit_map.cab_info.alto;


    for(i = 0 ; i < filas ; i++)
    {
        for(j = 0 ; j < bit_map.cab_info.ancho ; j++)
        {
            for(k = 0 ; k < 3 ; k++)
            {
                byte=bit_map.pixeles[i][j].bgr[k];
                fwrite(&byte,1,1,nuevaimagen);
            }
        }
        for(k=0; k<padding; k++)
        {
            fwrite(&cero,sizeof(cero),1,nuevaimagen);
        }
    }
    printf("\nimagen creada\n");
    fclose(nuevaimagen);

}
/////////////////////////////////////////////////EXTRAER NUMERO////////////////////////////////////////////////
int extraerNumeroDesdeIgual(char *str, int *out) {
    char *igual = strchr(str, '=');
    if (!igual || *(igual + 1) == '\0') {
        return 0;
    }

    char *numero = igual + 1;
    size_t len = strlen(numero);

    if (len == 0 || len > 3) return 0;


    for (size_t i = 0; i < len; ++i) {
        if (!isdigit(numero[i])) return 0;
    }


    int valor = atoi(numero);


    if (valor < 0 || valor > 100) return 0;

    *out = (int)valor;
    return 1;
}
//////////////////////////////////////////////INVERTIR VERTICAL/////////////////////////
void invertirVertical(PIXEL **matriz, size_t filas) {
    for (size_t i = 0; i < filas / 2; i++) {
        PIXEL *temp = matriz[i];
        matriz[i] = matriz[filas - 1 - i];
        matriz[filas - 1 - i] = temp;
    }
}


