#ifndef FUNCIONES_ZACARIAS_H_INCLUDED
#define FUNCIONES_ZACARIAS_H_INCLUDED

void EspejarVertical(IMAGEN bit_map,char *nom_imagen);
void AumentarContraste(IMAGEN bit_map,char *nom_imagen,float porcentaje);
void TonalidadRoja(IMAGEN bit_map,char *nom_imagen,float porcentaje);
void TonalidadVerde(IMAGEN bit_map,char *nom_imagen,float porcentaje);
void recortarImagen(IMAGEN bit_map, char *nom_imagen, float porcentaje);
void RotarIzquierda(IMAGEN bit_map, char *nom_imagen);
void ConcatenarHorizontal(IMAGEN bit_map, char *nom_imagen, char *nom_imagen1);
void Comodin(IMAGEN bit_map, char *nom_imagen);

#endif // FUNCIONES_ZACARIAS_H_INCLUDED
