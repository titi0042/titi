#ifndef FUNCIONES_LUNA_H_INCLUDED
#define FUNCIONES_LUNA_H_INCLUDED

void Negativo(IMAGEN bit_map,char *nom_imagen);
void EscaladeGrises(IMAGEN bit_map,char *nom_imagen);
void EspejarHorizontal(IMAGEN bit_map,char *nom_imagen);
void ReducirContraste(IMAGEN bit_map,char *nom_imagen,float porcentaje);
void TonalidadAzul(IMAGEN bit_map,char *nom_imagen,float porcentaje);
void AchicarImagen(IMAGEN bit_map,char *nom_imagen, float factor);
void RotarDerecha(IMAGEN bit_map, char *nom_imagen);
void ConcatenarVertical(IMAGEN bit_map, char *nom_imagen, char *nom_imagen1);


#endif // FUNCIONES_LUNA_H_INCLUDED
